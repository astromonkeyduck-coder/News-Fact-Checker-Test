#!/usr/bin/env node
'use strict';

const fs = require('fs');
const path = require('path');
const { cpSync } = require('fs');

const ROOT = path.resolve(__dirname, '../../../../');
const VENDOR = path.join(__dirname, 'vendor');
const NM = path.join(ROOT, 'node_modules');

function copyDir(from, to) {
  fs.mkdirSync(path.dirname(to), { recursive: true });
  cpSync(from, to, { recursive: true });
}

const coreUmd = path.join(NM, '@ffmpeg/core/dist/umd');
const ffmpegEsm = path.join(NM, '@ffmpeg/ffmpeg/dist/esm');
const utilEsm = path.join(NM, '@ffmpeg/util/dist/esm');

for (const p of [coreUmd, ffmpegEsm, utilEsm]) {
  if (!fs.existsSync(p)) {
    console.error('Missing:', p);
    console.error('Run: npm install @ffmpeg/core @ffmpeg/ffmpeg @ffmpeg/util');
    process.exit(1);
  }
}

fs.mkdirSync(VENDOR, { recursive: true });
fs.copyFileSync(path.join(coreUmd, 'ffmpeg-core.js'), path.join(VENDOR, 'ffmpeg-core.js'));
fs.copyFileSync(path.join(coreUmd, 'ffmpeg-core.wasm'), path.join(VENDOR, 'ffmpeg-core.wasm'));
copyDir(ffmpegEsm, path.join(VENDOR, 'esm'));
copyDir(utilEsm, path.join(VENDOR, 'util'));

console.log('[copy-vendor] FFmpeg WASM copied to extension/vendor/');
