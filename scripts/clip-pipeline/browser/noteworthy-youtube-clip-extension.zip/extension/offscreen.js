import { FFmpeg } from './vendor/esm/index.js';

let ffmpeg = null;
let loadPromise = null;

async function getFfmpeg() {
  if (ffmpeg?.loaded) return ffmpeg;
  if (!loadPromise) {
    loadPromise = (async () => {
      const instance = new FFmpeg();
      await instance.load({
        coreURL: chrome.runtime.getURL('vendor/ffmpeg-core.js'),
        wasmURL: chrome.runtime.getURL('vendor/ffmpeg-core.wasm'),
      });
      ffmpeg = instance;
      return instance;
    })();
  }
  return loadPromise;
}

async function convertWebmToMp4(arrayBuffer) {
  const ff = await getFfmpeg();
  await ff.writeFile('input.webm', new Uint8Array(arrayBuffer));
  const code = await ff.exec([
    '-i', 'input.webm',
    '-map', '0:v:0?',
    '-map', '0:a:0?',
    '-c:v', 'libx264',
    '-preset', 'ultrafast',
    '-pix_fmt', 'yuv420p',
    '-vf', "scale='min(1280,iw)':-2",
    '-r', '30',
    '-c:a', 'aac',
    '-b:a', '128k',
    '-ar', '48000',
    '-movflags', '+faststart',
    'output.mp4',
  ]);
  if (code !== 0) {
    throw new Error(`FFmpeg conversion failed (code ${code})`);
  }
  return await ff.readFile('output.mp4');
}

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message.type !== 'OFFSCREEN_CONVERT') {
    return false;
  }

  (async () => {
    try {
      const mp4 = await convertWebmToMp4(message.buffer);
      const bytes = mp4 instanceof Uint8Array ? mp4 : new Uint8Array(mp4);
      sendResponse({ ok: true, bytes: Array.from(bytes) });
    } catch (err) {
      sendResponse({ ok: false, error: err.message || String(err) });
    }
  })();

  return true;
});
