const bufferSelect = document.getElementById('bufferSeconds');
const saveBtn = document.getElementById('saveNow');
const openYtBtn = document.getElementById('openYoutube');
const msg = document.getElementById('msg');

function show(text, type) {
  msg.textContent = text;
  msg.className = `msg ${type || ''}`;
}

chrome.storage.sync.get({ bufferSeconds: 30 }, (data) => {
  bufferSelect.value = String(data.bufferSeconds);
});

bufferSelect.addEventListener('change', () => {
  const value = parseInt(bufferSelect.value, 10);
  chrome.storage.sync.set({ bufferSeconds: value }, () => {
    show(`Buffer set to ${value}s`, 'ok');
  });
});

saveBtn.addEventListener('click', () => {
  show('Saving…');
  chrome.runtime.sendMessage({ type: 'SAVE_FROM_POPUP' }, (response) => {
    if (chrome.runtime.lastError) {
      show(chrome.runtime.lastError.message, 'error');
      return;
    }
    if (!response?.ok) {
      show(response?.error || 'Failed — open a YouTube watch page.', 'error');
      return;
    }
    show(`Saved ~${response.seconds || '?'}s clip`, 'ok');
  });
});

openYtBtn.addEventListener('click', () => {
  chrome.tabs.create({ url: 'https://www.youtube.com/' });
});
