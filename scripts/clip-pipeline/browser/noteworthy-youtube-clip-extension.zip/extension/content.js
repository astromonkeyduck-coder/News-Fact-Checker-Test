/**
 * Noteworthy YouTube clip extension — content script.
 * Saves last N seconds as MP4 (WebM capture → ffmpeg.wasm conversion in offscreen doc).
 */
(function () {
  'use strict';

  const DEFAULT_BUFFER_SECONDS = 30;
  const SLICE_MS = 1000;

  let bufferSeconds = DEFAULT_BUFFER_SECONDS;
  let chunks = [];
  let recorder = null;
  let attachedVideo = null;
  let button = null;
  let statusEl = null;
  let saving = false;

  function loadSettings(cb) {
    chrome.storage.sync.get({ bufferSeconds: DEFAULT_BUFFER_SECONDS }, (data) => {
      bufferSeconds = data.bufferSeconds || DEFAULT_BUFFER_SECONDS;
      if (button) button.textContent = `Save last ${bufferSeconds}s`;
      cb();
    });
  }

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== 'sync' || !changes.bufferSeconds) return;
    bufferSeconds = changes.bufferSeconds.newValue || DEFAULT_BUFFER_SECONDS;
    if (button) button.textContent = `Save last ${bufferSeconds}s`;
    if (attachedVideo) startBuffer(attachedVideo);
  });

  function findVideo() {
    return (
      document.querySelector('video.html5-main-video') ||
      document.querySelector('#movie_player video') ||
      document.querySelector('ytd-watch-flexy video') ||
      document.querySelector('video')
    );
  }

  function pickMimeType() {
    const candidates = [
      'video/webm;codecs=vp9,opus',
      'video/webm;codecs=vp8,opus',
      'video/webm',
    ];
    return candidates.find((t) => MediaRecorder.isTypeSupported(t)) || '';
  }

  function setStatus(text, isError) {
    if (!statusEl) return;
    statusEl.textContent = text;
    statusEl.classList.toggle('error', Boolean(isError));
  }

  function setSaving(active) {
    saving = active;
    if (button) {
      button.disabled = active;
      button.style.opacity = active ? '0.65' : '1';
    }
  }

  function stopRecorder() {
    if (recorder && recorder.state !== 'inactive') {
      try {
        recorder.stop();
      } catch {
        /* ignore */
      }
    }
    recorder = null;
  }

  function startBuffer(video) {
    if (!video || video.readyState < 2) return;

    stopRecorder();
    chunks = [];

    let stream;
    try {
      stream = video.captureStream();
    } catch (err) {
      setStatus('Capture blocked (DRM?). Try another stream.', true);
      console.error('[Noteworthy clip]', err);
      return;
    }

    if (!stream.getVideoTracks().length) {
      setStatus('No video track to capture.', true);
      return;
    }

    const mimeType = pickMimeType();
    if (!mimeType) {
      setStatus('MediaRecorder not supported.', true);
      return;
    }

    try {
      recorder = new MediaRecorder(stream, { mimeType });
    } catch (err) {
      setStatus('Could not start recorder.', true);
      console.error('[Noteworthy clip]', err);
      return;
    }

    recorder.ondataavailable = (event) => {
      if (event.data && event.data.size > 0) {
        chunks.push(event.data);
        while (chunks.length > bufferSeconds) {
          chunks.shift();
        }
        if (!saving) {
          setStatus(`Buffering ${chunks.length}s / ${bufferSeconds}s`);
        }
      }
    };

    recorder.onerror = () => setStatus('Recorder error — refresh page.', true);

    recorder.start(SLICE_MS);
    if (!saving) setStatus(`Buffer active (${bufferSeconds}s)`);
  }

  function downloadBlob(blob, filename) {
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = filename;
    link.click();
    URL.revokeObjectURL(url);
  }

  async function saveLast() {
    if (saving) {
      return { ok: false, error: 'Already saving…' };
    }

    if (!chunks.length) {
      return { ok: false, error: 'Nothing buffered yet. Play the video first.' };
    }

    const secs = Math.min(chunks.length, bufferSeconds);
    const stamp = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
    const filename = `youtube-last-${secs}s-${stamp}.mp4`;

    const webmBlob = new Blob(chunks, { type: chunks[0].type || 'video/webm' });

    setSaving(true);
    setStatus('Converting to MP4… (first save may take ~15s)');

    try {
      const webmBuffer = await webmBlob.arrayBuffer();
      const response = await chrome.runtime.sendMessage({
        type: 'CONVERT_WEBM',
        buffer: webmBuffer,
      });

      if (!response?.ok || !response.bytes) {
        throw new Error(response?.error || 'MP4 conversion failed');
      }

      const mp4Blob = new Blob([new Uint8Array(response.bytes)], { type: 'video/mp4' });
      downloadBlob(mp4Blob, filename);
      setStatus(`Saved ${secs}s MP4`);
      return { ok: true, seconds: secs, format: 'mp4' };
    } catch (err) {
      console.error('[Noteworthy clip] MP4 conversion failed:', err);
      setStatus(`MP4 failed: ${err.message}`, true);
      return { ok: false, error: err.message };
    } finally {
      setSaving(false);
    }
  }

  function mountUi() {
    if (document.getElementById('noteworthy-yt-clip-wrap')) return;

    const wrap = document.createElement('div');
    wrap.id = 'noteworthy-yt-clip-wrap';

    statusEl = document.createElement('div');
    statusEl.className = 'nw-clip-status';
    statusEl.textContent = 'Waiting for video…';

    button = document.createElement('button');
    button.id = 'noteworthy-yt-clip-save';
    button.type = 'button';
    button.textContent = `Save last ${bufferSeconds}s`;
    button.title = 'Save last N seconds as MP4 (Alt+Shift+C)';
    button.addEventListener('click', async (e) => {
      e.preventDefault();
      e.stopPropagation();
      const result = await saveLast();
      if (!result.ok) alert(result.error);
    });

    wrap.appendChild(statusEl);
    wrap.appendChild(button);
    document.body.appendChild(wrap);
  }

  function attachToCurrentVideo() {
    const video = findVideo();
    if (!video) {
      if (!saving) setStatus('No video on this page');
      return;
    }

    if (video === attachedVideo && recorder && recorder.state === 'recording') {
      return;
    }

    attachedVideo = video;
    startBuffer(video);

    if (!video.dataset.noteworthyClipHooked) {
      video.dataset.noteworthyClipHooked = '1';
      video.addEventListener('play', () => startBuffer(video));
      video.addEventListener('loadeddata', () => startBuffer(video));
    }
  }

  function onNavigate() {
    attachedVideo = null;
    stopRecorder();
    chunks = [];
    setTimeout(attachToCurrentVideo, 1200);
  }

  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (message.type === 'SAVE_LAST') {
      saveLast().then((result) => {
        if (!result.ok) alert(result.error);
        sendResponse(result);
      });
      return true;
    }
    return false;
  });

  loadSettings(() => {
    mountUi();
    attachToCurrentVideo();
    setInterval(attachToCurrentVideo, 2000);

    window.addEventListener('yt-navigate-finish', onNavigate);
    window.addEventListener('yt-page-data-updated', onNavigate);
    document.addEventListener('visibilitychange', () => {
      if (document.visibilityState === 'visible') attachToCurrentVideo();
    });
  });
})();
