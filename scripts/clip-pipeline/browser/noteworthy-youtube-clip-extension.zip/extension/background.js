const OFFSCREEN_PATH = 'offscreen.html';

async function hasOffscreenDocument() {
  if (!chrome.offscreen) return false;
  const contexts = await chrome.runtime.getContexts({
    contextTypes: ['OFFSCREEN_DOCUMENT'],
    documentUrls: [chrome.runtime.getURL(OFFSCREEN_PATH)],
  });
  return contexts.length > 0;
}

async function ensureOffscreenDocument() {
  if (!chrome.offscreen) {
    throw new Error('Offscreen API not available. Update Chrome.');
  }
  if (await hasOffscreenDocument()) return;
  await chrome.offscreen.createDocument({
    url: OFFSCREEN_PATH,
    reasons: ['WORKERS'],
    justification: 'Convert captured WebM clips to MP4 before download',
  });
}

async function convertWebmToMp4(arrayBuffer) {
  await ensureOffscreenDocument();
  return new Promise((resolve, reject) => {
    chrome.runtime.sendMessage(
      { type: 'OFFSCREEN_CONVERT', buffer: arrayBuffer },
      (response) => {
        if (chrome.runtime.lastError) {
          reject(new Error(chrome.runtime.lastError.message));
          return;
        }
        if (!response?.ok) {
          reject(new Error(response?.error || 'Conversion failed'));
          return;
        }
        resolve(response.bytes);
      }
    );
  });
}

chrome.commands.onCommand.addListener((command) => {
  if (command !== 'save-clip') return;

  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    const tab = tabs[0];
    if (!tab?.id) return;
    chrome.tabs.sendMessage(tab.id, { type: 'SAVE_LAST' }).catch(() => {});
  });
});

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message.type === 'CONVERT_WEBM') {
    convertWebmToMp4(message.buffer)
      .then((bytes) => sendResponse({ ok: true, bytes }))
      .catch((err) => sendResponse({ ok: false, error: err.message }));
    return true;
  }

  if (message.type === 'SAVE_FROM_POPUP') {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      const tab = tabs[0];
      if (!tab?.id) {
        sendResponse({ ok: false, error: 'No active tab' });
        return;
      }
      chrome.tabs.sendMessage(tab.id, { type: 'SAVE_LAST' }, (response) => {
        if (chrome.runtime.lastError) {
          sendResponse({ ok: false, error: 'Open a YouTube watch page first.' });
          return;
        }
        sendResponse(response || { ok: true });
      });
    });
    return true;
  }

  return false;
});
